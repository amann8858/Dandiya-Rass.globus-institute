const express = require('express');
const session = require('express-session');
const multer = require('multer');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(ROOT, 'uploads');
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const PHOTOS_FILE = path.join(DATA_DIR, 'photos.json');
const LOGS_FILE = path.join(DATA_DIR, 'downloads.json');
const VISITORS_FILE = path.join(DATA_DIR, 'visitor-submissions.json');
for (const f of [PHOTOS_FILE, LOGS_FILE, VISITORS_FILE]) if (!fs.existsSync(f)) fs.writeFileSync(f, '[]');
if (!process.env.ADMIN_PASSWORD || !process.env.SESSION_SECRET) {
  console.warn('WARNING: Set ADMIN_PASSWORD and SESSION_SECRET in .env before using this site.');
}
function readJson(file) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return []; } }
function writeJson(file, value) { fs.writeFileSync(file, JSON.stringify(value, null, 2)); }
function safeName(name) { return String(name || '').replace(/[<>"'&]/g, '').trim().slice(0, 80); }

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use(session({
  name: 'globus_admin',
  secret: process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex'),
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'strict', secure: process.env.COOKIE_SECURE === 'true', maxAge: 2 * 60 * 60 * 1000 }
}));
app.use('/api/admin/login', rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(ROOT, 'public')));
function adminOnly(req, res, next) { if (req.session && req.session.isAdmin) return next(); return res.status(401).json({ error: 'Admin login required.' }); }
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => cb(null, crypto.randomUUID() + path.extname(file.originalname).toLowerCase())
});
const imageOnly = (req, file, cb) => {
  const allowed = ['image/jpeg', 'image/png', 'image/webp'];
  if (allowed.includes(file.mimetype)) cb(null, true); else cb(new Error('Only JPG, PNG, and WEBP image files are allowed.'));
};
const upload = multer({ storage, fileFilter: imageOnly, limits: { fileSize: 12 * 1024 * 1024, files: 30 } });
const selfieUpload = multer({ storage, fileFilter: imageOnly, limits: { fileSize: 5 * 1024 * 1024, files: 1 } });

app.get('/api/photos', (req, res) => {
  res.json(readJson(PHOTOS_FILE).map(({ id, name, createdAt }) => ({ id, name, createdAt })));
});
app.post('/api/visitor', selfieUpload.single('selfie'), (req, res) => {
  const name = safeName(req.body.name);
  const phone = String(req.body.phone || '').replace(/\D/g, '');
  const consent = req.body.consent === 'yes';
  if (name.length < 2 || !/^\d{10}$/.test(phone)) {
    if (req.file) fs.unlink(req.file.path, () => {});
    return res.status(400).json({ error: 'Enter your name and a valid 10-digit mobile number.' });
  }
  if (!consent) {
    if (req.file) fs.unlink(req.file.path, () => {});
    return res.status(400).json({ error: 'Please confirm the privacy notice to continue.' });
  }
  const visitorId = crypto.randomUUID();
  const record = { id: visitorId, name, phone, selfie: req.file ? path.basename(req.file.path) : null, createdAt: new Date().toISOString() };
  const visitors = readJson(VISITORS_FILE); visitors.push(record); writeJson(VISITORS_FILE, visitors);
  req.session.visitor = { id: visitorId, name, phone };
  res.json({ ok: true, message: 'Details saved. You can now download event photos.' });
});
app.get('/api/photo/:id/preview', (req, res) => {
  const photo = readJson(PHOTOS_FILE).find(p => p.id === req.params.id);
  if (!photo) return res.sendStatus(404);
  const filePath = path.join(UPLOAD_DIR, path.basename(photo.file));
  if (!fs.existsSync(filePath)) return res.sendStatus(404);
  res.setHeader('Cache-Control', 'public, max-age=3600');
  res.sendFile(filePath);
});
app.get('/api/photo/:id/download', (req, res) => {
  if (!req.session.visitor) return res.status(401).send('Please enter your name and mobile number first.');
  const photo = readJson(PHOTOS_FILE).find(p => p.id === req.params.id);
  if (!photo) return res.status(404).send('Photo not found.');
  const filePath = path.join(UPLOAD_DIR, path.basename(photo.file));
  if (!fs.existsSync(filePath)) return res.status(404).send('Photo file is missing.');
  const logs = readJson(LOGS_FILE);
  logs.push({ id: crypto.randomUUID(), photoId: photo.id, photoName: photo.name, visitorId: req.session.visitor.id, name: req.session.visitor.name, phone: req.session.visitor.phone, downloadedAt: new Date().toISOString() });
  writeJson(LOGS_FILE, logs);
  res.download(filePath, photo.name);
});
app.post('/api/admin/login', (req, res) => {
  const submitted = String(req.body.password || '');
  const expected = String(process.env.ADMIN_PASSWORD || '');
  if (!expected || submitted.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(submitted), Buffer.from(expected))) {
    return res.status(401).json({ error: 'Incorrect admin password.' });
  }
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: 'Could not start admin session.' });
    req.session.isAdmin = true;
    res.json({ ok: true });
  });
});
app.post('/api/admin/logout', adminOnly, (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get('/api/admin/data', adminOnly, (req, res) => res.json({ photos: readJson(PHOTOS_FILE).map(({id,name,createdAt})=>({id,name,createdAt})), visitors: readJson(VISITORS_FILE), downloads: readJson(LOGS_FILE).slice().reverse() }));
app.post('/api/admin/photos', adminOnly, upload.array('photos', 30), (req, res) => {
  const files = req.files || [];
  if (!files.length) return res.status(400).json({ error: 'Choose at least one image.' });
  const photos = readJson(PHOTOS_FILE);
  for (const f of files) photos.push({ id: crypto.randomUUID(), name: safeName(path.parse(f.originalname).name) + path.extname(f.originalname).toLowerCase(), file: path.basename(f.path), createdAt: new Date().toISOString() });
  writeJson(PHOTOS_FILE, photos);
  res.json({ ok: true, count: files.length });
});
app.delete('/api/admin/photo/:id', adminOnly, (req, res) => {
  const photos = readJson(PHOTOS_FILE); const photo = photos.find(p => p.id === req.params.id);
  if (!photo) return res.status(404).json({ error: 'Photo not found.' });
  const next = photos.filter(p => p.id !== req.params.id); writeJson(PHOTOS_FILE, next);
  const filePath = path.join(UPLOAD_DIR, path.basename(photo.file)); if (fs.existsSync(filePath)) fs.unlink(filePath, () => {});
  res.json({ ok: true });
});
app.get('/uploads/:file', (req, res) => {
  const file = path.basename(req.params.file);
  // Only event photos are public; selfies are never served through this route.
  const photo = readJson(PHOTOS_FILE).find(p => p.file === file);
  if (!photo) return res.sendStatus(404);
  res.sendFile(path.join(UPLOAD_DIR, file));
});
app.get('/health', (req, res) => res.json({ ok: true }));
app.use((err, req, res, next) => {
  console.error(err.message);
  if (err instanceof multer.MulterError) return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? 'Image is too large.' : 'Upload limit reached.' });
  res.status(400).json({ error: err.message || 'Request failed.' });
});
app.listen(PORT, () => console.log(`Dandiya gallery running on port ${PORT}`));
