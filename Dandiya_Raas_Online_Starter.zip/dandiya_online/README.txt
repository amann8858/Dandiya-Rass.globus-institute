GLOBUS INSTITUTE – DANDIYA RAAS ONLINE PHOTO GALLERY
===================================================

This is a real Node.js website starter (not just a browser-only HTML demo).
It includes:
- Public event photo gallery with search and download
- Name + 10-digit mobile number form before downloading
- Optional student selfie upload (visible only to admin in submission records; not publicly served)
- Password-protected admin login
- Admin photo uploads and delete option
- Records of student submissions and each successful download
- Image type/size limits and basic login rate limiting

IMPORTANT PRIVACY AND HOSTING NOTES
-----------------------------------
1. Students should be told clearly why their phone number is collected. The form includes a consent checkbox.
2. Do not collect selfies unless you genuinely need them. They are stored on the server and must be protected; delete them when no longer needed. This starter does not include an admin selfie-view/download function.
3. The app stores records in JSON files and images in the uploads folder. Your hosting provider must offer persistent disk/storage, or data can disappear on restart/redeploy. For a public production service, use a proper database and managed object storage.
4. Use HTTPS. Set COOKIE_SECURE=true when deployed behind HTTPS.
5. Set a strong unique ADMIN_PASSWORD and SESSION_SECRET. Do not use the password from a chat or a password used elsewhere. Never upload your .env file publicly.
6. This is a starter project and should be tested before sharing with students. Admin sessions use the default in-memory session store; for high traffic/production, configure a persistent session store.

RUN ON A COMPUTER
------------------
1. Install Node.js 20 or newer.
2. Extract this ZIP.
3. Open a terminal in the extracted folder.
4. Run: npm install
5. Copy .env.example to .env.
6. Edit .env and set ADMIN_PASSWORD and a long random SESSION_SECRET.
7. Run: npm start
8. Open http://localhost:3000

ONLINE DEPLOYMENT
-----------------
You need a Node.js hosting provider that supports a persistent disk/volume.
- Upload this project to a private Git repository (do not include .env, uploads, or data files).
- Create a Node web service from that repository. Build command: npm install; start command: npm start.
- Add environment variables ADMIN_PASSWORD, SESSION_SECRET, COOKIE_SECURE=true.
- Attach persistent storage and make sure the data/ and uploads/ directories are on that persistent disk. If your host mounts a disk at a different path, update server.js to use that mount path before deployment.
- Enable HTTPS, test admin upload, test student submission, and verify a download record appears before sharing the URL.

ADMIN ACCESS
------------
Open the website URL and tap “Admin”. Use the ADMIN_PASSWORD value configured in the hosting environment.

LIMITATIONS
-----------
- The website has not been deployed; no public URL is created by this ZIP alone.
- A hosting account and configuration are needed to publish it.
- Download logs are recorded when the server sends a photo download response; a browser may still cancel saving after the request begins.
